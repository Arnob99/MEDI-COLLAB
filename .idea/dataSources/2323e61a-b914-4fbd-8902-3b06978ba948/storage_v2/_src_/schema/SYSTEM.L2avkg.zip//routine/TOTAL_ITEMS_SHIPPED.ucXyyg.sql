create FUNCTION total_items_shipped(in_date NUMBER)
RETURN NUMBER
IS

total_items NUMBER(10, 3) := 0;

BEGIN

SELECT COUNT(OI.ITEM_ID)
INTO total_items
FROM ORDERS O, ORDER_ITEMS OI
WHERE O.ORDER_ID = OI.ORDER_ID AND O.ORDER_YEAR = in_date AND O.STATUS = 1;

RETURN total_items;

END;
/

